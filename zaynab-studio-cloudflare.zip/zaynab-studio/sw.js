const CACHE='zaynab-studio-v1'; const ASSETS=['./','./index.html','./manifest.webmanifest','./assets/zaynab-1.jpeg','./assets/zaynab-2.png','./assets/zaynab-3.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
